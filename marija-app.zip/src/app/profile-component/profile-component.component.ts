import { BinaryOperatorExpr } from '@angular/compiler';
import { Component, Inject, OnInit, Input } from '@angular/core';
import { Bio } from 'src/types/types';

@Component({
  selector: 'app-profile-component',
  templateUrl: './profile-component.component.html',
  styleUrls: ['./profile-component.component.css']
})



export class ProfileComponentComponent implements OnInit {
  @Input() biography?: Bio;



  ngOnInit(): void {
  }

  

}
