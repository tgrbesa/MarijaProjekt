import { Component } from '@angular/core';
import { Bio } from '../types/types'
import { ProfileComponentComponent } from './profile-component/profile-component.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'marija-app';
  biography: Bio = {
    firstName: "Cristoph",
    lastName: "Woltz",
    url: "Some shit",
    about: "Some other shit"
  };
  
}
