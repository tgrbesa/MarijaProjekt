export type Bio = {
    firstName: String,
    lastName: String,
    url: String,
    about: String
}